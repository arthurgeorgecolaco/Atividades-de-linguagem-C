/*
 * Exemplo do slide: encadeamento da estrutura de repeticao (for dentro de for).
 */
#include <stdio.h>

int main() {
    int contador1, contador2;

    for (contador1 = 0; contador1 < 3; contador1++) {
        for (contador2 = 0; contador2 < 3; contador2++) {
            printf("%d - %d\n", contador1, contador2);
        }
    }

    return 0;
}
