# Exercícios de Linguagem C - UNIPÊ

Atividades da disciplina de Linguagem C (Ciência da Computação, 1º período),
resolvidas em C e organizadas por tema.

## Estrutura

| Pasta | Conteúdo |
|---|---|
| `01-vetores-e-matrizes/` | Vetores paralelos, matriz 3x3 e laços encadeados |
| `02-funcoes/` | Questões 1 a 10 sobre funções |
| `03-desafios/` | Problemas maiores com vetores, funções, ordenação e classificação |
| `04-structs-e-arquivos/` | Structs, `malloc`/`realloc`, `memcpy`, arquivos texto e binário |

## Como compilar e executar

```bash
gcc -Wall -Wextra arquivo.c -o programa
./programa
```

O desafio 5 usa `sqrt`, então precisa de `-lm` no Linux:

```bash
gcc -Wall -Wextra 03-desafios/d5_participantes_diagonal.c -o d5 -lm
```

Para a atividade 3 de arquivos, gere antes um `clientes.bin` de teste:

```bash
cd 04-structs-e-arquivos
gcc criar_clientes.c -o criar_clientes && ./criar_clientes
gcc a3_clientes_fseek.c -o a3 && ./a3
```

## Observações

- Alguns enunciados tinham trechos ambíguos; as decisões de interpretação estão
  comentadas no topo de cada arquivo.
- Arquivos gerados pelos programas (`*.bin`, `*.dat`, `estoque.txt`) e
  executáveis estão no `.gitignore`.
